import random

class Auto:
    def __init__(self, tipo_gasolina, cantidad_gasolina):
        self.tipo_gasolina = tipo_gasolina
        self.cantidad_gasolina = cantidad_gasolina
        self.tiempo_espera = 0
        self.ticket = random.randint(1000, 9999)
