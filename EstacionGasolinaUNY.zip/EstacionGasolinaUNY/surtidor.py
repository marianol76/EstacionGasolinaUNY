import time
import random

class Surtidor:
    def __init__(self, numero, tipo_gasolina, capacidad=200):
        self.numero = numero
        self.tipo_gasolina = tipo_gasolina
        self.capacidad = capacidad
        self.disponible = capacidad
        self.ocupado = False
        self.tiempo_total = 0
        self.usos = 0

    def abastecer(self, auto):
        if self.disponible >= auto.cantidad_gasolina and not self.ocupado:
            self.ocupado = True
            tiempo = round(auto.cantidad_gasolina * random.uniform(0.05, 0.15), 2)
            time.sleep(tiempo)
            self.disponible -= auto.cantidad_gasolina
            self.tiempo_total += tiempo
            self.usos += 1
            print(f"Auto ticket #{auto.ticket} abastecido con {auto.cantidad_gasolina}L en surtidor #{self.numero} ({tiempo}s)")
            self.ocupado = False
            return tiempo
        else:
            return None
