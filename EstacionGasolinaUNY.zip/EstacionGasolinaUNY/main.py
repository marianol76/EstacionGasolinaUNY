from clase_auto import Auto
from clase_estacion import EstacionDeGasolina
import random

estacion = EstacionDeGasolina()

# Generar autos aleatorios con consumo variado
autos = []
for _ in range(random.randint(5, 10)):
    tipo = random.choice(["91", "95"])
    cantidad = random.randint(30, 90)
    autos.append(Auto(tipo, cantidad))

estacion.abastecer_autos(autos)
