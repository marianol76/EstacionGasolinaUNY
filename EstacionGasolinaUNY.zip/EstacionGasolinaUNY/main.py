from clase_auto import Auto
from clase_estacion import EstacionDeGasolina
import random

# Crea instancia de la estación
estacion = EstacionDeGasolina()

# Crea una lista aleatoria de autos (entre 4 y 8 autos)
autos = []
for _ in range(random.randint(4, 8)):
    tipo = random.choice(["91", "95"])
    litros = random.randint(15, 45)
    auto = Auto(tipo, litros)
    autos.append(auto)

# Abastecer los autos
estacion.abastecer_autos(autos)
