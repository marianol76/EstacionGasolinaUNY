import time
import random

class Surtidor:
    def __init__(self, numero, capacidad, tipo_gasolina):
        self.numero = numero
        self.capacidad = capacidad
        self.tipo_gasolina = tipo_gasolina
        self.cantidad_disponible = capacidad
        self.ocupado = False
        self.tiempos_abastecimiento = []
        self.contador_uso = 0

    def abastecer(self, auto):
        self.ocupado = True
        cantidad = auto.cantidad_gasolina
        tiempo = round(random.uniform(1.5, 3.5), 2)
        time.sleep(tiempo)

        if self.cantidad_disponible >= cantidad:
            self.cantidad_disponible -= cantidad
            self.tiempos_abastecimiento.append(tiempo)
            self.contador_uso += 1
            print(f"✅ Auto ticket #{auto.ticket} abastecido con {cantidad}L en surtidor #{self.numero} ({tiempo}s)")
        else:
            print(f"⚠️ Surtidor #{self.numero} sin suficiente gasolina para el auto ticket #{auto.ticket}")
        self.ocupado = False
