from clase_surtidor import Surtidor
import statistics

class EstacionDeGasolina:
    def __init__(self):
        self.surtidores = [
            Surtidor(1, 100, "91"),
            Surtidor(2, 100, "95"),
            Surtidor(3, 100, "95")
        ]
        self.autos_atendidos = 0
        self.total_litros = 0
        self.tiempos_totales = []

    def get_surtidor_disponible(self, tipo_gasolina):
        disponibles = [
            s for s in self.surtidores
            if not s.ocupado and s.tipo_gasolina == tipo_gasolina and s.cantidad_disponible > 0
        ]
        return disponibles[0] if disponibles else None

    def abastecer_auto(self, auto):
        surtidor = self.get_surtidor_disponible(auto.tipo_gasolina)
        if surtidor:
            surtidor.abastecer(auto)
            self.autos_atendidos += 1
            self.total_litros += auto.cantidad_gasolina
            if surtidor.tiempos_abastecimiento:
                self.tiempos_totales.append(surtidor.tiempos_abastecimiento[-1])
        else:
            print(f"🚫 Auto ticket #{auto.ticket} no pudo ser abastecido (sin surtidor disponible)")

    def abastecer_autos(self, cola_autos):
        for auto in cola_autos:
            self.abastecer_auto(auto)

        print("\n📊 ESTADÍSTICAS FINALES")
        print(f"Autos atendidos: {self.autos_atendidos}")
        print(f"Gasolina despachada: {self.total_litros}L")
        if self.tiempos_totales:
            promedio = round(statistics.mean(self.tiempos_totales), 2)
            print(f"Tiempo promedio por auto: {promedio}s")

        surtidor_mas_usado = max(self.surtidores, key=lambda s: s.contador_uso)
        print(f"Surtidor más usado: #{surtidor_mas_usado.numero} ({surtidor_mas_usado.contador_uso} veces)")
