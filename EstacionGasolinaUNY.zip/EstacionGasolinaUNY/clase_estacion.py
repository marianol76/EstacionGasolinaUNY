import random
from surtidor import Surtidor

class EstacionDeGasolina:
    def __init__(self):
        self.surtidores = [
            Surtidor(1, "91"),
            Surtidor(2, "95"),
            Surtidor(3, "95")
        ]
        self.historial = []

    def get_surtidor_disponible(self, tipo):
        disponibles = [s for s in self.surtidores if s.tipo_gasolina == tipo and not s.ocupado and s.disponible > 0]
        return random.choice(disponibles) if disponibles else None

    def abastecer_autos(self, autos):
        total_tiempo = 0
        total_gasolina = 0
        atendidos = 0

        for auto in autos:
            surtidor = self.get_surtidor_disponible(auto.tipo_gasolina)
            if surtidor:
                tiempo = surtidor.abastecer(auto)
                if tiempo:
                    total_tiempo += tiempo
                    total_gasolina += auto.cantidad_gasolina
                    atendidos += 1
                    self.historial.append((auto, surtidor.numero, tiempo))
            else:
                print(f"Auto ticket #{auto.ticket} no pudo ser abastecido (sin surtidor disponible)")

        self.estadisticas(atendidos, total_gasolina, total_tiempo)

    def estadisticas(self, atendidos, gasolina, tiempo):
        print("\nESTADÍSTICAS FINALES")
        print(f"Autos atendidos: {atendidos}")
        print(f"Gasolina despachada: {gasolina}L")
        print(f"Tiempo promedio por auto: {round(tiempo/atendidos, 2) if atendidos > 0 else 0}s")

        if self.historial:
            surtidor_uso = {}
            for _, nro, _ in self.historial:
                surtidor_uso[nro] = surtidor_uso.get(nro, 0) + 1
            mas_usado = max(surtidor_uso, key=surtidor_uso.get)
            print(f"Surtidor más usado: #{mas_usado} ({surtidor_uso[mas_usado]} veces)")
